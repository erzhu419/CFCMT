# CFCMT: revised IEEE T-ITS manuscript

The revised manuscript follows the supplied draft's section structure and prose
where compatible with the implemented V93 controller. It includes six figures
from recorded experiments, the complete six-controller confirmation, three
development screens, and the necessary component-score proofs.

Build from this directory:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The source uses the bundled IEEEtran class and bibliography style. The figure
PDFs are ready to compile; Python is needed only to regenerate the figures:

```bash
python3 figure_source/build_real_figures.py
```

Plot dependencies are numpy, pandas, and matplotlib. `source_data/` contains
the 1,344 confirmation records, paired statistical exports, eight-seed
development records, and the fixed-case departure-cohort extraction with its
source metadata. The full native experiment archive is required to repeat
simulation execution. The source package contains the records used for figures
and tables; no model files are included.

The author names follow the supplied draft. Affiliations, membership details,
and funding acknowledgments remain for the authors to confirm.
