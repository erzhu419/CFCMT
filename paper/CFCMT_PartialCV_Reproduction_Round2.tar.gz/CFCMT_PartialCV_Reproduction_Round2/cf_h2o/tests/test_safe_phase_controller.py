from types import SimpleNamespace

import pytest

from cf_h2o.traffic_signal.safe_phase_controller import (
    PhaseTiming,
    SafePhaseExecutor,
    build_safe_phase_executors,
    _junction_clearance_lane_ids,
)


class _TrafficLight:
    def __init__(self):
        self.writes = []

    def setRedYellowGreenState(self, tls_id, state):
        self.writes.append((tls_id, state))


class _Sumo:
    def __init__(self):
        self.trafficlight = _TrafficLight()
        self.lane = _Lane()


class _Lane:
    def __init__(self):
        self.vehicles = {}

    def getIDList(self):
        return tuple(self.vehicles)

    def getLastStepVehicleNumber(self, lane_id):
        return self.vehicles.get(lane_id, 0)


def _executor(*, initial_elapsed=5.0):
    api = _Sumo()
    executor = SafePhaseExecutor(
        sumo_api=api,
        tls_id="J0",
        timings=(
            PhaseTiming("GGrr", min_green_sec=5.0, yellow_sec=3.0, all_red_sec=1.0),
            PhaseTiming("rrGG", min_green_sec=5.0, yellow_sec=3.0, all_red_sec=1.0),
        ),
        initial_state="GGrr",
        initial_green_elapsed_sec=initial_elapsed,
    )
    return api, executor


def test_switch_executes_yellow_all_red_then_target_green():
    api, executor = _executor()

    assert executor.request("rrGG")
    assert api.trafficlight.writes == [("J0", "YYrr")]
    executor.advance(3.0)
    assert api.trafficlight.writes[-1] == ("J0", "rrrr")
    executor.advance(1.0)
    assert api.trafficlight.writes[-1] == ("J0", "rrGG")
    assert executor.mode == "green"
    assert executor.audit.switches == 1
    assert executor.audit.yellow_seconds == pytest.approx(3.0)
    assert executor.audit.all_red_seconds == pytest.approx(1.0)


def test_mixed_green_priority_is_retained_through_yellow_clearance():
    api = _Sumo()
    current = "rrrrrGGGggrrrrrGGGgg"
    target = "GGGGGrrrrrsrrrrrrrrr"
    yellow = "rrrrrYYYyyrrrrrYYYyy"
    executor = SafePhaseExecutor(
        sumo_api=api,
        tls_id="J0",
        timings=(
            PhaseTiming(current, min_green_sec=5.0, yellow_sec=3.0, all_red_sec=1.0),
            PhaseTiming(target, min_green_sec=5.0, yellow_sec=3.0, all_red_sec=1.0),
        ),
        initial_state=current,
        initial_green_elapsed_sec=6.0,
    )

    assert executor.request(target)
    assert executor.current_state == yellow
    assert executor.current_state[17] == "Y"  # Prioritized straight movement.
    assert executor.current_state[9] == "y"  # Yielding U-turn movement.
    for remaining in (2.0, 1.0):
        executor.advance(1.0)
        assert executor.current_state == yellow
        assert executor.mode == "yellow"
        assert executor.remaining_sec == remaining
        assert executor.green_elapsed_sec == 6.0
        assert executor.target_green_state == target

    executor.advance(1.0)
    assert executor.mode == "all_red"
    assert executor.remaining_sec == 1.0
    executor.advance(1.0)
    assert executor.mode == "green"
    assert executor.green_elapsed_sec == 0.0
    assert api.trafficlight.writes == [
        ("J0", yellow), ("J0", "r" * len(current)), ("J0", target),
    ]
    assert executor.audit.yellow_seconds == 3.0
    assert executor.audit.all_red_seconds == 1.0


def test_minimum_green_and_busy_requests_are_rejected():
    _, executor = _executor(initial_elapsed=2.0)

    assert executor.feasible_states_now() == ("GGrr",)
    assert not executor.request("rrGG")
    assert executor.audit.rejected_min_green == 1
    executor.advance(3.0)
    assert executor.request("rrGG")
    assert executor.feasible_states_now() == ("rrGG",)
    assert not executor.request("GGrr")
    assert executor.audit.rejected_busy == 1


def test_same_phase_request_does_not_reset_minimum_green_clock():
    api, executor = _executor(initial_elapsed=1.0)

    assert not executor.request("GGrr")
    assert executor.green_elapsed_sec == pytest.approx(1.0)
    assert not api.trafficlight.writes
    assert executor.audit.same_phase_requests == 1


@pytest.mark.parametrize("occupied", [False, True])
def test_all_red_takeover_runs_native_clearance_before_entering_green(occupied):
    api = _Sumo()
    phases = [
        SimpleNamespace(state=state, duration=duration)
        for state, duration in (("rrrr", 5), ("rrGG", 30), ("GGrr", 20))
    ]
    api.trafficlight.getAllProgramLogics = lambda _: [SimpleNamespace(phases=phases)]
    api.trafficlight.getRedYellowGreenState = lambda _: "rrrr"
    api.trafficlight.getSpentDuration = lambda _: 0
    api.trafficlight.getPhase = lambda _: 0
    api.trafficlight.getNextSwitch = lambda _: 5
    api.simulation = SimpleNamespace(getTime=lambda: 0)
    info = SimpleNamespace(
        candidates=(phases[2], phases[1]),
        controlled_links=((("in", "out", ":J0_0"),),),
    )
    executor = build_safe_phase_executors(api, {"J0": info})["J0"]
    api.lane.vehicles[":J0_0"] = int(occupied)

    assert executor.mode == "all_red"
    assert executor.feasible_states_now() == ("rrGG",)
    assert not executor.request("rrGG")
    executor.advance(4)
    assert api.trafficlight.writes == [("J0", "rrrr")]

    executor.advance(1)
    if occupied:
        assert api.trafficlight.writes == [("J0", "rrrr")]
        assert executor.audit.occupancy_clearance_extensions == 1
        api.lane.vehicles[":J0_0"] = 0
        executor.advance(1)

    assert api.trafficlight.writes == [("J0", "rrrr"), ("J0", "rrGG")]
    assert executor.mode == "green"
    assert executor.green_elapsed_sec == 0
    assert not executor.request("rrGG")
    assert not executor.request("GGrr")  # The minimum-green clock starts at green.


def test_projected_clearance_is_zero_for_stay_and_explicit_for_switch():
    _, executor = _executor()

    assert executor.projected_clearance_sec("GGrr") == pytest.approx(0.0)
    assert executor.projected_clearance_sec("rrGG") == pytest.approx(4.0)


def test_unknown_or_malformed_phases_fail_fast():
    _, executor = _executor()
    with pytest.raises(KeyError):
        executor.request("GrrG")
    with pytest.raises(ValueError):
        SafePhaseExecutor(
            sumo_api=_Sumo(),
            tls_id="J0",
            timings=(PhaseTiming("GG", 5.0, 3.0, 1.0),),
            initial_state="GGrr",
        )


def test_runtime_snapshot_restore_rewinds_clearance_and_audit():
    api, executor = _executor()
    saved = executor.snapshot()
    assert executor.request("rrGG")
    executor.advance(3.0)
    assert executor.mode == "all_red"
    assert executor.audit.switches == 1

    executor.restore(saved)

    assert executor.mode == "green"
    assert executor.current_state == "GGrr"
    assert executor.current_green_state == "GGrr"
    assert executor.target_green_state == "GGrr"
    assert executor.green_elapsed_sec == pytest.approx(5.0)
    assert executor.audit.switches == 0
    assert api.trafficlight.writes[-1] == ("J0", "GGrr")


def test_all_red_extends_until_internal_clearance_lane_is_empty():
    api = _Sumo()
    executor = SafePhaseExecutor(
        sumo_api=api,
        tls_id="J0",
        timings=(
            PhaseTiming("GGrr", min_green_sec=5.0, yellow_sec=3.0, all_red_sec=1.0),
            PhaseTiming("rrGG", min_green_sec=5.0, yellow_sec=3.0, all_red_sec=1.0),
        ),
        initial_state="GGrr",
        initial_green_elapsed_sec=5.0,
        clearance_lane_ids=(":J0_0",),
    )
    api.lane.vehicles[":J0_0"] = 1

    assert executor.request("rrGG")
    executor.advance(3.0)
    executor.advance(1.0)

    assert executor.mode == "all_red"
    assert api.trafficlight.writes[-1] == ("J0", "rrrr")
    assert executor.audit.occupancy_clearance_extensions == 1
    assert executor.audit.occupancy_clearance_extension_seconds == pytest.approx(1.0)

    api.lane.vehicles[":J0_0"] = 0
    executor.advance(1.0)

    assert executor.mode == "green"
    assert api.trafficlight.writes[-1] == ("J0", "rrGG")


def test_clearance_lanes_expand_to_all_internal_segments_of_junction():
    api = _Sumo()
    api.lane.vehicles = {
        ":J0_4_0": 0,
        ":J0_21_0": 1,
        ":J1_4_0": 1,
        "external": 1,
    }

    lanes = _junction_clearance_lane_ids(
        api,
        ((('in', 'out', ':J0_4_0'),),),
    )

    assert lanes == (":J0_4_0", ":J0_21_0")
