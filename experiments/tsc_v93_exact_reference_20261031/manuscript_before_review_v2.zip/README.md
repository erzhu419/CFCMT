# CFCMT: revised IEEE T-ITS manuscript

`main.tex` is the single manuscript source, including the appendix. The 18
references are in `main.bbl`; there are no section TeX files and no BibTeX step.
The bundled `IEEEtran.cls` supplies the journal layout.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The current main PDF is 10 pages with four figures and three tables.
`Supplementary_material.pdf` has two pages: departure-cohort Fig. S1 and the
complete logged-decision counts and rates in Table S1. The three component-score
proofs remain in the main appendix and are cited from the method and discussion.

To regenerate all four main figures and the supplementary PDF:

```bash
python3 figure_source/build_real_figures.py
```

Plot dependencies are numpy, pandas, and matplotlib. `source_data/` contains
1,344 existing one-hour evaluation records, paired statistical exports,
eight-seed development records, a fixed-case departure-cohort extraction,
seed-history evidence, and compact execution and simulator-incident summaries.
The execution summaries were aggregated from existing server JSON records;
this revision adds no simulations, replays, fitting, or parameter selection.
The full native archive is needed to repeat simulation execution; model files
and raw native logs are excluded from this source package.

The eight selection seeds and 56 evaluation seeds are disjoint in this round,
but their union is the previously used 64-seed benchmark panel. The reported
intervals and tests concern that reused panel. CFCMT almost always follows its
generalized-pressure reference in Jinan; the exact standalone reference was not
evaluated, so the learning layer's incremental benefit is not established.
`execution_summary.metadata.json` defines the counters and denominators.

This revision adopts verified published records for the nine formerly preprint
references; `reference_versions.csv` and `reference_publication_updates.json`
record the sources. The original arXiv identifiers remain metadata only.

Author order: Yifan Zhang, Liang Zheng, Qifan Zhang, and Haoming Li. Liang Zheng
is the corresponding author. `main.pdf`, `main_gemini.pdf`, and
`CFCMT_Gemini_V93_TITS.pdf` are identical copies of the current build. Historical
five/six-figure export bundles are not inputs to this manuscript or source ZIP.
