# Manuscript terminology

CFCMT = Causal-Factored Cross-City Model Transfer.
The method uses supervised action-cost prediction with predeployment target adaptation.
Source components combine restricted-reference and antisymmetric pairwise predictors.
The component blend alpha_g differs from source-mixture weights omega_n,k.
The target anchor T_g differs from the generalized-pressure execution reference r_g.
Guard multiplier beta_n scales heuristic error scores, not risk probabilities.
Use MaxPressure (MP), PhasePressure (PP), target anchor, equal source weights,
and dense linear residual; the dense residual is not the published H2O+ algorithm.
The evaluation has 56 paired seeds, four scenarios, six controllers, 1344 runs.
The current eight development seeds are disjoint from the evaluation panel;
both cohorts reuse an earlier 64-seed benchmark panel.
Primary effects average ratios within city and seed, then average cities and seeds.
The MP aggregate comparison is favorable on this panel; the PP interval crosses zero.
Accepted non-reference switch requests and effective current-green holds count as
effective overrides; these are not completed green-phase transitions.
Raw collision events sum colliding-vehicle counts; incidents deduplicate vehicle
pair, type, and lane within a run. Teleport starts and ends remain separate.
Four main figures: framework, source selection, waiting distributions, and guard.
Supplementary Fig. S1 shows departure-cohort waiting; Table S1 gives execution rates.
